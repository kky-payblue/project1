import { NgModule } from '@angular/core';
import {NoPreloading, RouterModule, Routes} from '@angular/router';
import {StepAgreementComponent} from './step-agreement/step-agreement.component';
import {StepInputFranchiseCodeComponent} from './step-input-franchise-code/step-input-franchise-code.component';
import {AuthGuard} from './auth.guard';
import {StepInputSeller01Component} from './step-input-seller01/step-input-seller01.component';
import {StepInputSeller02Component} from './step-input-seller02/step-input-seller02.component';
import {StepInputSeller03Component} from './step-input-seller03/step-input-seller03.component';
import {StepInputSeller04Component} from './step-input-seller04/step-input-seller04.component';
import {StepInputSeller05Component} from './step-input-seller05/step-input-seller05.component';
import {StepInputSeller06Component} from './step-input-seller06/step-input-seller06.component';
import {StepPayment01Component} from './step-payment01/step-payment01.component';
import {NotFoundComponent} from './not-found/not-found.component';
import {StepStartComponent} from './step-start/step-start.component';
import {StepAgreement2Component} from './step-agreement2/step-agreement2.component';

const routes: Routes = [
  // { path: '', redirectTo: '/step-agreement', pathMatch: 'full' },
  { path: '', component: StepStartComponent },
  { path: 'step-agreement', canActivate: [AuthGuard], component: StepAgreementComponent },
  { path: 'step-agreement2', canActivate: [AuthGuard], component: StepAgreement2Component },
  { path: 'step-input-franchise-code', canActivate: [AuthGuard], component: StepInputFranchiseCodeComponent },
  { path: 'step-input-seller01', canActivate: [AuthGuard], component: StepInputSeller01Component },
  { path: 'step-input-seller02', canActivate: [AuthGuard], component: StepInputSeller02Component },
  { path: 'step-input-seller03', canActivate: [AuthGuard], component: StepInputSeller03Component },
  { path: 'step-input-seller04', canActivate: [AuthGuard], component: StepInputSeller04Component },
  { path: 'step-input-seller05', canActivate: [AuthGuard], component: StepInputSeller05Component },
  { path: 'step-input-seller06', canActivate: [AuthGuard], component: StepInputSeller06Component },

  { path: 'step-payment01', canActivate: [AuthGuard], component: StepPayment01Component },

  {path: '404', component: NotFoundComponent},
  {path: '**', redirectTo: '/404'}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes, {preloadingStrategy: NoPreloading}) ],
  exports: [ RouterModule ]
})

export class AppRoutingModule { }
