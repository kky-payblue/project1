import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'PayBlue-Apply';

  ngOnInit() {
    window.addEventListener('beforeunload', function (e) {
      if (localStorage.completed === 'true') {
        return;
      }

      if (localStorage.Start === 'true') {
        const confirmationMessage = '신청을 종료합니까?';
        e.returnValue = <any>confirmationMessage;     // Gecko, Trident, Chrome 34+
        return confirmationMessage;              // Gecko, WebKit, Chrome <34
      }
    });

  }
}
