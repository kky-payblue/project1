import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {AppComponent} from './app.component';
import {StepAgreementComponent} from './step-agreement/step-agreement.component';
import {AppRoutingModule} from './app-routing.module';
import {StepInputFranchiseCodeComponent} from './step-input-franchise-code/step-input-franchise-code.component';
import {StepInputSeller01Component} from './step-input-seller01/step-input-seller01.component';
import {StepInputSeller02Component} from './step-input-seller02/step-input-seller02.component';
import {StepInputSeller03Component} from './step-input-seller03/step-input-seller03.component';
import {StepInputSeller04Component} from './step-input-seller04/step-input-seller04.component';
import {StepInputSeller05Component} from './step-input-seller05/step-input-seller05.component';
import {StepInputSeller06Component} from './step-input-seller06/step-input-seller06.component';
import {StepPayment01Component} from './step-payment01/step-payment01.component';
import {HttpClientModule} from '@angular/common/http';
import {CurrencyPipe} from '@angular/common';
import {SharedService} from './services/sharedService';
import {DatePipe} from './pipes/date.pipe';
import {NumberPipe} from './pipes/number.pipe';
import {environment} from '../environments/environment';
import {AngularFireModule} from '@angular/fire';
import {AngularFireStorageModule} from '@angular/fire/storage';
import {NotFoundComponent} from './not-found/not-found.component';
import { StepStartComponent } from './step-start/step-start.component';
import { StepAgreement2Component } from './step-agreement2/step-agreement2.component';

@NgModule({
  declarations: [
    AppComponent,
    StepAgreementComponent,
    StepInputFranchiseCodeComponent,
    StepInputSeller01Component,
    StepInputSeller02Component,
    StepInputSeller03Component,
    StepInputSeller04Component,
    StepInputSeller05Component,
    StepInputSeller06Component,
    StepPayment01Component,

    DatePipe,
    NumberPipe,
    NotFoundComponent,
    StepStartComponent,
    StepAgreement2Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,

    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireStorageModule
  ],
  providers: [
    CurrencyPipe,
    DatePipe,
    NumberPipe,

    SharedService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
