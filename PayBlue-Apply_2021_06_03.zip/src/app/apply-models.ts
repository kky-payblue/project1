import {SharedService} from './services/sharedService';

interface SellerApplicationData {

  ts;

  versionCode: string;

  frName: string;
  frAddress: string;
  frTel: string;
  frCode: string;
  frOnlineDealingDevice: string;

  sellerType: string;

  name: string;
  tel: string;

  telKind: string; // 'SKT', 'KT', 'LGT', 'MVNO'
  phoneKind: string; // 'iPhone', 'Android'

  regNo: string;
  email: string;

  postCode: string;
  address: string;
  addressDetail: string;

  shopName: string;
  shopItem: string;

  shopPostCode: string;
  shopAddress: string;
  shopAddressDetail: string;

  businessNo: string;

  bankKind: string; // 'KB', 'KEB'
  accountNo: string;
  accountName: string;
  signImageDataUrl: string;

  membershipFee: string; // 'once_50000', '5month_50000'
  serviceItemKind: string; // 'PB200', 'PB400', 'PBBIZ'

  readerDeviceKind: string; // 'none', 'icBlueCheck_145000', 'offline_icBlueCheck_145000'
  printerKind: string; // 'none', 'btSewoo_140000', 'offline_icBlueCheck_145000'

  membershipFeeAmountVal: number;
  readerDeviceAmountVal: number;
  printerAmountVal: number;

  finalAmountVal: number;

  paymentType: string; // NONE, CARD
  paymentApprovalDateTime: string;
  paymentApprovalNo: string;
  paymentCardNo: string;
  paymentCardIssuerName: string;
  paymentCardAcquirerName: string;

  dbPath: string;

  idCardPicPath: string;
  bankBookPicPath: string;
  businessLicensePicPath: string;
  applicationFormPath: string;
}
