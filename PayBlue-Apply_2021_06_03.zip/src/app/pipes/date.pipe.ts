import { Pipe, PipeTransform } from '@angular/core';
import {SharedService} from '../services/sharedService';

@Pipe({
    name: 'datepipe'
})

/**
 * value | showTime:true
 */
export class DatePipe implements PipeTransform {

    /**
     * @param value yyyy[-]mm[-]dd[ ]hh[:]mi[:]ss] string | ts number | Date
     * @param showTime
     * @returns {any}
     */
    transform(value: string | number | Date, showTime: boolean = true): any {

        if (!value ){
            return '';
        }

        let date : Date = null;

        if( typeof value === 'string' ) {
            let str = value.replace(/-/g, '').replace(/ /g, '');

            if (str.length == 14){
                date = SharedService.getGMTDateFromLocalyyyymmddhhmiss(str);
            }
            else if (str.length == 8){
                date = SharedService.getGMTDateFromLocalyyyymmddhhmiss(str+'000000');
            }
            else {
                date = null;
            }
        }
        else if( typeof value === 'number' ) {
            date = new Date(value);
        }
        else if( value instanceof Date ) {
            date = value;
        }

        let result;
        if( date ) {
            if( showTime ) {
                result = SharedService.getyyyy_mm_dd_hh$mi$ss(date);
            }
            else {
                result = SharedService.getyyyy_mm_dd(date);
            }
        }
        else {
            result = value;
        }
        return result;
    }
}
