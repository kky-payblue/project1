import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'numberpipe'
})

export class NumberPipe implements PipeTransform {

    transform(value: any, masking = false, account = false): any {

        let result = '';
        let str1, str2, str3, str4, str5 = '';

        if (value == null || value == ''){
            return result;
        }

        let str = value.replace(/-/g, '');

        if (account){
            let maxLangth = str.length
            //return value.slice(maxLangth-5, maxLangth).replace(/#/gi, '*')
            return value.slice(0, maxLangth-5) + '*****'
        }

        if (str.length == 10) {

            //전화번호 02-0000-0000
            if ('02' == str.substring(0, 2)) {
                str1 = str.substring(0, 2) + '-';
                str2 = masking ? '****-' : str.substring(2, 2 + 4) + '-';
                str3 = str.substring(6, 6 + 4);

                result = str1 + str2 + str3;

            }
            //전화번호 010-000-0000
            else if ('0' == str.substring(0, 1)) {
                str1 = str.substring(0, 3) + '-';
                str2 = masking ? '***-' : str.substring(3, 3 + 3) + '-';
                str3 = str.substring(6, 6 + 4);

                result = str1 + str2 + str3;
        }
            //사업자번호
            else {
                str1 = str.substring(0, 3) + '-';
                str2 = masking ? '**-' : str.substring(3, 3 + 2) + '-';
                str3 = str.substring(5, 5 + 5);

                result = str1 + str2 + str3;
            }
        }
        //1688-0000
        else if (str.length == 8){
            str1 = str.substring(0, 2);
            str2 = masking ? '**-' : str.substring(2, 2 + 2) + '-';
            str3 = masking ? '**' : str.substring(4, 4 + 2);
            str4 = str.substring(6, 6 + 2);

            result = str1 + str2 + str3 + str4;
        }
        //000-0000-0000
        else if (str.length == 11){

            str1 = str.substring(0, 3) + '-';
            str2 = masking ? '****-' : str.substring(3, 3 + 4) + '-';
            str3 = str.substring(7, 7 + 4);

            result = str1 + str2 + str3;
        }
        //주민등록번호
        else if (str.length == 13){
            str1 = str.substring(0, 6) + '-';
            str2 = masking ? '*******' : str.substring(6, 6 + 7);

            result = str1 + str2;
        }
        //카드번호
        else if (str.length == 16){
            str1 = str.substring(0, 4) + '-';
            str2 = str.substring(4, 6);
            str3 = masking ? '**-' : str.substring(6, 8) + '-';
            str4 = masking ? '****-' : str.substring(8, 12) + '-';
            str5 = str.substring(12, 12 + 4);

            result = str1 + str2 + str3 + str4 + str5;
        }
        //카드번호 다이너스티
        else if (str.length == 14){
            str1 = str.substring(0, 4) + '-';
            str2 = masking ? '******-' : str.substring(4, 10) + '-';
            str3 = str.substring(10, 14);

            result = str1 + str2 + str3;
        }
        //카드번호 AMEX
        else if (str.length == 15){
            str1 = str.substring(0, 4) + '-';
            str2 = str.substring(4, 6);
            str3 = masking ? '**' : str.substring(6, 8);
            str4 = masking ? '***-' : str.substring(8, 11) + '-';
            str5 = str.substring(11, 11 + 4);

            result = str1 + str2 + str3 + str4 + str5;
        }
        //현금영수증 카드번호
        else if (str.length == 18){
            str1 = str.substring(0, 4) + '-';
            str2 = str.substring(4, 6);
            str3 = masking ? '**-' : str.substring(6, 8) + '-';
            str4 = masking ? '******-' : str.substring(8, 8 + 4) + '-';
            str5 = str.substring(12, 12 + 6);

            result = str1 + str2 + str3 + str4 + str5;
        }
        //은련카드 일부
        else if (str.length == 19){
            str1 = str.substring(0, 6) + '-';
            str2 = masking ? '******' : str.substring(6, 12);
            str3 = str.substring(12, 19);

            result = str1 + str2 + str3;
        }
        else {
            result = str;
        }

        return result;
    }
}
