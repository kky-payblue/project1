import {FormControl} from '@angular/forms';

/**
 * Created by hsnoh on 2016-05-19.
 */

export class SharedService {

  static UTCOffsetHours = 9;
  static UTCOffsetMillis = (60 * 60 * SharedService.UTCOffsetHours * 1000);

  validatorAny = '*';
  validatorNo = '[0-9]*';
  validatorRegNo = '[0-9]{6}-?[0-9]{7}';
  validatorBusinessNo = '[0-9]{3}-?[0-9]{2}-?[0-9]{5}';
  validatorEmail = '^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$';
  validatorLoginId = '^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)';
  validatorRate = '^-?[0-9]{0,2}(\.[0-9]{1,2})?$|^-?(100)(\.[0]{1,2})?$';
  validatorHp = '(^010-?([0-9]{4})-?([0-9]{4}))|(^01([1|6|7|8|9])-?([0-9]{3,4})-?([0-9]{4}))';

  // expHpSplitterPattern = /(^02.{0}|^01.{1}|[0-9]{3})([0-9]{3,4})([0-9]{4})?/;
  expTelSplitterPattern = /^(010)([0-9]{4})([0-9]{4})?|(^02.{0}|^01[1-9]|[0-9]{3})([0-9]{3,4})([0-9]{4})/;
  expRegNoSplitterPattern = /([0-9]{6})([0-9]{7})?/;
  expBusinessNoSplitterPattern = /([0-9]{3})([0-9]{2})([0-9]{5})?/;

  calendarLocale: any = {
    // date
    firstDayOfWeek: 0,
    closeText: '닫기',
    prevText: '이전달',
    nextText: '다음달',
    currentText: '오늘',
    monthNames: ['1월', '2월', '3월', '4월', '5월', '6월',
      '7월', '8월', '9월', '10월', '11월', '12월'],
    monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월',
      '7월', '8월', '9월', '10월', '11월', '12월'],
    dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
    dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
    weekHeader: '주',
    dateFormat: 'yy-mm-dd',
    firstDay: 0,
    isRTL: false,
    showMonthAfterYear: true,
    yearSuffix: '년',

    // time
    timeOnlyTitle: '시간 선택',
    timeText: '시간',
    hourText: '시',
    minuteText: '분',
    secondText: '초',
    millisecText: '밀리초',
    microsecText: '마이크로',
    timezoneText: '표준 시간대',
    timeFormat: 'tt h:mm',
    timeSuffix: '',
    amNames: ['오전', 'AM', 'A'],
    pmNames: ['오후', 'PM', 'P']
  };



  constructor() {
    const now = new Date();
  }

  removeDash(str: string) {
    if (!str) {
      return null;
    }
    return str.replace(/-/g, '');
  }

  performTelNoSplit(c: any, el: any, event) {
    if (event && event.which === 8) {
      return;
    }

    if (!c || !el.value ) {
      return;
    }

    c.setValue(el.value.replace(/-/g, '').replace( this.expTelSplitterPattern, '$1$4-$2$5-$3$6' ));
  }

  performRegNoSplit(c: any, el: any, event) {
    if (event && event.which === 8) {
      return;
    }

    if (!c || !el.value ) {
      return;
    }

    c.setValue(el.value.replace(/-/g, '').replace( this.expRegNoSplitterPattern, '$1-$2' ));
  }

  performBusinessNoSplit(c: any, el: any, event) {
    if (event && event.which === 8) {
      return;
    }

    if (!c || !el.value ) {
      return;
    }

    c.setValue(el.value.replace(/-/g, '').replace( this.expBusinessNoSplitterPattern, '$1-$2-$3' ));
  }

  str(c: any) {
    return SharedService.Str(c);
  }

  static Str(c: any) {
    if (!c) {
      return '';
    }

    return String(c);
  }

  static s2ab(s: string): ArrayBuffer {
    const buf: ArrayBuffer = new ArrayBuffer(s.length);
    const view: Uint8Array = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  static setNullUnderScoreProperties(obj: any) {
    Object.getOwnPropertyNames(obj)
      .filter(p => {
        return p.startsWith('_');
      })
      .forEach(p => {
        obj[p] = null;
      });
  }



  static getyyyy_mm_dd_hh$mi$ssFromStr(dateTimeString: string): string {
    if(!dateTimeString) {
      return '';
    }
    try {
      return dateTimeString.substr(0, 4) + '-' +
        dateTimeString.substr(4, 2) + '-' +
        dateTimeString.substr(6, 2) + ' ' +
        dateTimeString.substr(8, 2) + ':' +
        dateTimeString.substr(10, 2) + ':' +
        dateTimeString.substr(12, 2);
    }
    catch(e) {
      return '';
    }
  }


  static getGMTDateFromLocalyyyymmddhhmiss(dateTimeString: string): Date {
    let yyyy = Number(dateTimeString.substr(0, 4));
    let mm = Number(dateTimeString.substr(4, 2));
    let dd = Number(dateTimeString.substr(6, 2));

    let hh = Number(dateTimeString.substr(8, 2));
    let mi = Number(dateTimeString.substr(10, 2));
    let ss = Number(dateTimeString.substr(12, 2));
    return new Date(Date.UTC(yyyy, mm - 1, dd, hh, mi, ss, 0) - SharedService.UTCOffsetMillis);
  }

  static getyyyymmddhhmiss(dateTime?: Date): string {
    if (dateTime == null) {
      dateTime = new Date();
    }

    dateTime = new Date(dateTime.getTime() + SharedService.UTCOffsetMillis);

    let val = dateTime.toISOString();
    val = val.replace(/[\D]/g, '');
    val = val.substr(0, 14);
    return val;
  }

  static getyyyymmdd(dateTime?: Date): string {
    return this.getyyyymmddhhmiss(dateTime).substr(0, 8);
  }

  static gethhmiss(dateTime?: Date): string {
    return this.getyyyymmddhhmiss(dateTime).substr(8, 6);
  }

  static getyyyy_mm_dd_hh$mi$ss(dateTime?: Date): string {
    return this.getyyyy_mm_dd(dateTime) + ' ' + this.gethh$mi$ss(dateTime);
  }

  static getyyyy_mm_dd(dateTime?: Date): string  {
    if (dateTime == null) {
      dateTime = new Date();
    }

    dateTime = new Date(dateTime.getTime() + SharedService.UTCOffsetMillis);

    var dateFormated = dateTime.toISOString().substr(0,10);
    return dateFormated;
  }

  static gethh$mi$ss(dateTime?: Date): string {
    if (dateTime == null) {
      dateTime = new Date();
    }

    dateTime = new Date(dateTime.getTime() + SharedService.UTCOffsetMillis);

    var dateFormated = dateTime.toISOString().substr(11,8);
    return dateFormated;
  }



  static getRandomInt(min?:number, max?:number): number {
    min = min ? min : Number.MIN_SAFE_INTEGER;
    max = max ? max : Number.MAX_SAFE_INTEGER;

    return Math.floor(Math.random() * (max - min)) + min;
  }

  static getRandomPasswd(): string {
    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}';

    for( var i = 0; i < 16; i++ ) {
      var idx = Math.floor(Math.random() * possible.length);

      text += possible.charAt(idx);

      possible = possible.substring(0, idx) + possible.substring(idx + 1, possible.length - 1);
    }

    return text;
  }

  static getFileExt(fileName): string {
    return (/[.]/.exec(fileName)) ? /[^.]+$/.exec(fileName)[0] : '';
  }

  static getFileName(filePath): string {
    var filename = filePath.substring(filePath.lastIndexOf('/') + 1);
    return filename;
  }
}
