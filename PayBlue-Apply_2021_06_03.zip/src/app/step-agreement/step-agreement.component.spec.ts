import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepAgreementComponent } from './step-agreement.component';

describe('StepAgreementComponent', () => {
  let component: StepAgreementComponent;
  let fixture: ComponentFixture<StepAgreementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepAgreementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepAgreementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
