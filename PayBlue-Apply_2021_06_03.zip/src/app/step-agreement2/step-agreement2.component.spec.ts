import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepAgreement2Component } from './step-agreement2.component';

describe('StepAgreement2Component', () => {
  let component: StepAgreement2Component;
  let fixture: ComponentFixture<StepAgreement2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepAgreement2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepAgreement2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
