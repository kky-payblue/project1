import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';

import {
  zip
} from 'rxjs';
import {FormControl, FormGroup} from '@angular/forms';
import {SharedService} from '../services/sharedService';

declare var UIkit: any;
declare var SignaturePad: any;

@Component({
  selector: 'app-step-agreement2',
  templateUrl: './step-agreement2.component.html',
  styleUrls: ['./step-agreement2.component.css']
})
export class StepAgreement2Component implements OnInit {

  agreeAll: any = null;
  agree1: any = null;
  agree1text = '';

  fieldDisabled = 'disabled';

  signaturePad;


  myGroup = new FormGroup({
    tel: new FormControl('')
  });

  @ViewChild('signaturePadEl') signaturePadRef: ElementRef;

  @ViewChild('modalAgree') modalAgreeRef: ElementRef;
  @ViewChild('modalSign') modalSignRef: ElementRef;

  constructor(private router: Router, private http: HttpClient, public ss: SharedService) { }

  ngOnInit() {

    this.signaturePad = new SignaturePad(this.signaturePadRef.nativeElement);

    zip(
      this.http.get('assets/text/agreement4.txt', {responseType: 'text'})
    ).subscribe( datas => {

      this.agree1text = datas[0];

      this.fieldDisabled = '';
    });

  }

  onPrev() {
    this.router.navigate(['/step-input-seller02'], { replaceUrl: false });
  }

  onNext() {
    if ( !this.agreeAll ) {
      UIkit.modal(this.modalAgreeRef.nativeElement).show();
      return;
    }

    localStorage.Agree = 'true';
    UIkit.modal(this.modalSignRef.nativeElement).show();
  }

  onAgreeAllChange(v: any) {
    this.agree1 = true;
  }

  onAgreeChange() {
    this.agreeAll = this.agree1;
  }

  onCloseModal(modal) {
    UIkit.modal(modal).hide();
  }

  onSignatureClear() {
    this.signaturePad.clear();
  }

  onSignConfirm(modal) {

    UIkit.modal(modal).hide();

    if (this.agreeAll && !this.signaturePad.isEmpty() ) {

      localStorage.signImageDataUrlKspay = this.signaturePad.toDataURL();
      console.log(localStorage.signImageDataUrlKspay);

      this.router.navigate(['/step-input-seller03'], { replaceUrl: false });
    }
  }

}
