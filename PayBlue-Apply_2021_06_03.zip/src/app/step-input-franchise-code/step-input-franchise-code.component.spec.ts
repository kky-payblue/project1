import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputFranchiseCodeComponent } from './step-input-franchise-code.component';

describe('StepInputFranchiseCodeComponent', () => {
  let component: StepInputFranchiseCodeComponent;
  let fixture: ComponentFixture<StepInputFranchiseCodeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputFranchiseCodeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputFranchiseCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
