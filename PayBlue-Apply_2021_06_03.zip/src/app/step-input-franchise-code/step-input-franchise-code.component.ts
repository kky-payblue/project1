import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import {FormControl, FormGroup} from '@angular/forms';

declare var UIkit: any;

@Component({
  selector: 'app-step-input-franchise-code',
  templateUrl: './step-input-franchise-code.component.html',
  styleUrls: ['./step-input-franchise-code.component.css']
})
export class StepInputFranchiseCodeComponent implements OnInit {

  myForm = new FormGroup({
    frCode: new FormControl('')
  });

  frCode = null;
  frInfo: any = {};

  // bind
  frInfoConfirmed: any = {};

  // bind
  sellerType: any = null;

  msg = null;

  @ViewChild('modalConfirm') modalConfirmRef: ElementRef;

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {
    if (localStorage.frCode) {
      this.frCode = localStorage.frCode;
    }
    if (localStorage.sellerType) {
      this.sellerType = localStorage.sellerType;
    }
  }

  onPrev() {
    this.frInfoConfirmed = {};
    this.sellerType = null;
  }

  onNext() {
    if (this.sellerType) {
      localStorage.sellerType = this.sellerType;
      this.router.navigate(['/step-input-seller01'], { replaceUrl: false });
    }
  }

  onConfirm() {
    UIkit.modal(this.modalConfirmRef.nativeElement).hide();

    this.frInfoConfirmed = this.frInfo;

    localStorage.frCode = this.frInfoConfirmed.code;
    localStorage.frOnlineDealingDevice = this.frInfoConfirmed.onlineDealingDevice;
    localStorage.frName = this.frInfoConfirmed.name;
    localStorage.frAddress = this.frInfoConfirmed.address;
    localStorage.frTel = this.frInfoConfirmed.tel;
  }

  onSearchFormSubmit() {

    let frCode = '';
    if (this.frCode) {
      frCode = this.frCode.toString();
    }

    if ( !frCode || frCode.length === 0 ) {
      frCode = '1006';
    } else if ( frCode.length !== 4 ) {
      this.msg = '* 대리점 코드 4자리를 입력해주세요.';
      return;
    }

    this.msg = '조회중입니다.';

    this.http.get(environment.functionUrl + '/q_fr_s1/FR' + frCode).toPromise()
      .catch( error => {
        throw new Error('서버 오류(1)');
      })
      .then((res: any) => {
          console.log(res);
          this.msg = null;

          if (!res.name ) {
            throw new Error('대리점 코드가 정확하지 않습니다.');
          }

          if (res.status !== '0') {
            throw new Error('정지된 대리점 코드입니다. (반복 오류시 본사 문의 요망)');
          }

          this.frInfo = res;
          this.frInfo.code = frCode;

          UIkit.modal(this.modalConfirmRef.nativeElement).show();

        }
      )
      .catch( error => {
        this.msg = error.toString();
      });
  }
}
