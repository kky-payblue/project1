import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputSeller01Component } from './step-input-seller01.component';

describe('StepInputSeller01Component', () => {
  let component: StepInputSeller01Component;
  let fixture: ComponentFixture<StepInputSeller01Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputSeller01Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputSeller01Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
