import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import {FormControl, FormGroup, NgForm} from '@angular/forms';
import {SharedService} from '../services/sharedService';

@Component({
  selector: 'app-step-input-seller01',
  templateUrl: './step-input-seller01.component.html',
  styleUrls: ['./step-input-seller01.component.css']
})
export class StepInputSeller01Component implements OnInit {

  myForm = new FormGroup({
    name: new FormControl(''),
    tel: new FormControl('')
  });


  individual = true;

  @ViewChild('telKindSkt') telKindSkt: ElementRef;
  @ViewChild('telKindKt') telKindKt: ElementRef;
  @ViewChild('telKindLgt') telKindLgt: ElementRef;
  @ViewChild('telKindMvno') telKindMvno: ElementRef;

  @ViewChild('telKindIphone') telKindIphone: ElementRef;
  @ViewChild('telKindAndroid') telKindAndroid: ElementRef;

  constructor(private router: Router, public ss: SharedService) {
  }

  ngOnInit() {

    if (!localStorage.frCode ) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    this.individual = localStorage.sellerType === 'individual';

    this.myForm.controls.name.setValue( localStorage.name );
    this.myForm.controls.tel.setValue( localStorage.tel );

    switch (localStorage.telKind) {
      case 'SKT':
        this.onTelecomClick(this.telKindSkt.nativeElement,
          this.telKindKt.nativeElement, this.telKindLgt.nativeElement, this.telKindMvno.nativeElement);
        break;

      case 'KT':
        this.onTelecomClick(this.telKindKt.nativeElement,
          this.telKindSkt.nativeElement, this.telKindLgt.nativeElement, this.telKindMvno.nativeElement);
        break;

      case 'LGT':
        this.onTelecomClick(this.telKindLgt.nativeElement,
          this.telKindKt.nativeElement, this.telKindSkt.nativeElement, this.telKindMvno.nativeElement);
        break;

      case 'MVNO':
        this.onTelecomClick(this.telKindMvno.nativeElement,
          this.telKindKt.nativeElement, this.telKindLgt.nativeElement, this.telKindSkt.nativeElement);
        break;
    }

    if (navigator.appVersion.indexOf('Mac OS') !== -1) {
      this.onPhoneClick(this.telKindIphone.nativeElement, this.telKindAndroid.nativeElement);
    } else {
      this.onPhoneClick(this.telKindAndroid.nativeElement, this.telKindIphone.nativeElement);
    }
  }

  onPrev() {
    if (this.myForm.touched) {
      if (!confirm('이전 단계로 이동하시겠습니까?')) {
        return;
      }
    }

    this.router.navigate(['/step-input-franchise-code'], { replaceUrl: false });
  }

  onNext() {
    console.log(this.myForm);

    const telKind = this.telKind;
    const phoneKind = this.phoneKind;

    if (this.myForm.valid && telKind && phoneKind) {

      localStorage.name = this.myForm.value.name;
      localStorage.tel = this.myForm.value.tel;

      localStorage.telKind = telKind;
      localStorage.phoneKind = phoneKind;

      this.router.navigate(['/step-input-seller02'], { replaceUrl: false });
    }
  }

  get telKind() {
    if ( this.telKindSkt.nativeElement.selected ) {
      return 'SKT';
    }

    if ( this.telKindKt.nativeElement.selected ) {
      return 'KT';
    }

    if ( this.telKindLgt.nativeElement.selected ) {
      return 'LGT';
    }

    if ( this.telKindMvno.nativeElement.selected ) {
      return 'MVNO';
    }

    return null;
  }

  get phoneKind() {

    if (this.telKindIphone.nativeElement.selected ) {
      return 'iPhone';
    }

    if (this.telKindAndroid.nativeElement.selected ) {
      return 'Android';
    }

    return null;
  }

  onTelecomClick(a, b, c, d) {
    a.selected = true;
    a.className = a.className.replace('uk-button-default', 'uk-button-primary');

    [b, c, d].forEach( v => {
      v.selected = false;
      v.className = v.className.replace('uk-button-primary', 'uk-button-default');
    });
  }

  onPhoneClick(a, b) {
    a.selected = true;
    b.selected = false;
    a.className = a.className.replace('uk-button-default', 'uk-button-primary');
    b.className = b.className.replace('uk-button-primary', 'uk-button-default');
  }


}
