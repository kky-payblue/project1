import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputSeller02Component } from './step-input-seller02.component';

describe('StepInputSeller02Component', () => {
  let component: StepInputSeller02Component;
  let fixture: ComponentFixture<StepInputSeller02Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputSeller02Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputSeller02Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
