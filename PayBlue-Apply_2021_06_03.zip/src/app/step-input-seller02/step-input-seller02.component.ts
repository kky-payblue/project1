import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {FormControl, FormGroup} from '@angular/forms';
import {SharedService} from '../services/sharedService';
import {stringify} from 'querystring';

declare var daum: any;

@Component({
  selector: 'app-step-input-seller02',
  templateUrl: './step-input-seller02.component.html',
  styleUrls: ['./step-input-seller02.component.css']
})
export class StepInputSeller02Component implements OnInit {

  myForm = new FormGroup({
    regNo: new FormControl(''),
    sex: new FormControl(''),
    email: new FormControl(''),

    postCode: new FormControl(''),
    address: new FormControl(''),
    addressDetail: new FormControl(''),


    shopName: new FormControl(''),
    shopItem: new FormControl(''),

    shopPostCode: new FormControl(''),
    shopAddress: new FormControl(''),
    shopAddressDetail: new FormControl(''),

    businessNo: new FormControl('')
  });

  individual = true;



  constructor(private router: Router, public ss: SharedService) {
  }

  ngOnInit() {
    if (!localStorage.name ) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    this.individual = localStorage.sellerType === 'individual';

    this.myForm.controls.regNo.setValue(localStorage.regNo);
    this.myForm.controls.sex.setValue(localStorage.sex);
    this.myForm.controls.email.setValue(localStorage.email);

    this.myForm.controls.postCode.setValue(localStorage.postCode);
    this.myForm.controls.address.setValue(localStorage.address);
    this.myForm.controls.addressDetail.setValue(localStorage.addressDetail);

    this.myForm.controls.shopName.setValue(localStorage.shopName);
    this.myForm.controls.shopItem.setValue(localStorage.shopItem);

    this.myForm.controls.shopPostCode.setValue(localStorage.shopPostCode);
    this.myForm.controls.shopAddress.setValue(localStorage.shopAddress);
    this.myForm.controls.shopAddressDetail.setValue(localStorage.shopAddressDetail);

    this.myForm.controls.businessNo.setValue(localStorage.businessNo);
  }

  // foldDaumPostcode() {
  //   const element_wrap = document.getElementById('wrap');
  //
  //   // iframe을 넣은 element를 안보이게 한다.
  //   element_wrap.style.display = 'none';
  // }

  onCopyAddress() {
    console.log(this.myForm);
    console.log(this.myForm.get('postCode'));
    this.myForm.controls.shopPostCode.setValue(this.myForm.value.postCode);
    this.myForm.controls.shopAddress.setValue(this.myForm.value.address);
    this.myForm.controls.shopAddressDetail.setValue(this.myForm.value.addressDetail);
  }

  onAddressSearchClick(wrap, postCode, address, element_focus) {
    const element_wrap = wrap;

    if (element_wrap.style.display === 'block') {
      element_wrap.style.display = 'none';
      return;
    }

    // 현재 scroll 위치를 저장해놓는다.
    const currentScroll = Math.max(document.body.scrollTop, document.documentElement.scrollTop);
    new daum.Postcode({
      oncomplete: (data) => {
        // 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

        // 각 주소의 노출 규칙에 따라 주소를 조합한다.
        // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
        let addr = ''; // 주소 변수
        let extraAddr = ''; // 참고항목 변수

        // 사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
        if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
          addr = data.roadAddress;
        } else { // 사용자가 지번 주소를 선택했을 경우(J)
          addr = data.jibunAddress;
        }

        // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
        if (data.userSelectedType === 'R'){
          // 법정동명이 있을 경우 추가한다. (법정리는 제외)
          // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
          if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
            extraAddr += data.bname;
          }
          // 건물명이 있고, 공동주택일 경우 추가한다.
          if (data.buildingName !== '' && data.apartment === 'Y'){
            extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
          }
          // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
          if (extraAddr !== '') {
            extraAddr = ' (' + extraAddr + ')';
          }
          // 조합된 참고항목을 해당 필드에 넣는다.
          // document.getElementById("sample3_extraAddress").value = extraAddr;
        } else {
          // document.getElementById("sample3_extraAddress").value = '';
        }



        // 우편번호와 주소 정보를 해당 필드에 넣는다.
        address.setValue(addr + extraAddr);
        postCode.setValue(data.zonecode);

        // 커서를 상세주소 필드로 이동한다.
        element_focus.focus();

        // iframe을 넣은 element를 안보이게 한다.
        // (autoClose:false 기능을 이용한다면, 아래 코드를 제거해야 화면에서 사라지지 않는다.)
        element_wrap.style.display = 'none';

        // 우편번호 찾기 화면이 보이기 이전으로 scroll 위치를 되돌린다.
        document.body.scrollTop = currentScroll;
      },
      // 우편번호 찾기 화면 크기가 조정되었을때 실행할 코드를 작성하는 부분. iframe을 넣은 element의 높이값을 조정한다.
      onresize : (size) => {
        element_wrap.style.height = size.height + 'px';
      },
      width : '100%',
      height : '100%'
    }).embed(element_wrap);

    // iframe을 넣은 element를 보이게 한다.
    element_wrap.style.display = 'block';
  }

  onPrev() {
    if (this.myForm.touched) {
      if (!confirm('이전 단계로 이동하시겠습니까?')) {
        return;
      }
    }

    this.router.navigate(['/step-input-seller01'], { replaceUrl: false });
  }

  onNext() {
    console.log(this.myForm);

    if (this.myForm.valid ) {

      localStorage.regNo = this.myForm.value.regNo;
      localStorage.sex = this.myForm.value.sex;
      localStorage.email = this.myForm.value.email;

      localStorage.postCode = this.myForm.value.postCode;
      localStorage.address = this.myForm.value.address;
      localStorage.addressDetail = this.myForm.value.addressDetail || '';

      localStorage.shopName = this.myForm.value.shopName || '';
      localStorage.shopItem = this.myForm.value.shopItem || '';

      localStorage.shopPostCode = this.myForm.value.shopPostCode;
      localStorage.shopAddress = this.myForm.value.shopAddress;
      localStorage.shopAddressDetail = this.myForm.value.shopAddressDetail || '';

      localStorage.businessNo = this.myForm.value.businessNo || '';

      this.router.navigate(['/step-agreement'], { replaceUrl: false });
    }
  }
}
