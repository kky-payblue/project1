import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputSeller03Component } from './step-input-seller03.component';

describe('StepInputSeller03Component', () => {
  let component: StepInputSeller03Component;
  let fixture: ComponentFixture<StepInputSeller03Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputSeller03Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputSeller03Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
