import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import {FormControl, FormGroup} from '@angular/forms';

declare var UIkit: any;
declare var SignaturePad: any;

@Component({
  selector: 'app-step-input-seller03',
  templateUrl: './step-input-seller03.component.html',
  styleUrls: ['./step-input-seller03.component.css']
})
export class StepInputSeller03Component implements OnInit {

  myForm = new FormGroup({
    bankKind: new FormControl(''),
    accountNo: new FormControl(''),
    accountName: new FormControl('')
  });

  signaturePad;
  agree1;

  @ViewChild('signaturePadEl') signaturePadRef: ElementRef;
  // @ViewChild('bankKB') bankKB: ElementRef;
  // @ViewChild('bankKEB') bankKEB: ElementRef;

  @ViewChild('modalAgree') modalAgreeRef: ElementRef;
  @ViewChild('modalSign') modalSignRef: ElementRef;

  constructor(private router: Router) { }

  ngOnInit() {
    if (!localStorage.regNo ) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    this.signaturePad = new SignaturePad(this.signaturePadRef.nativeElement);

    this.myForm.controls.accountNo.setValue( localStorage.accountNo );
    this.myForm.controls.accountName.setValue( localStorage.accountName );
    this.myForm.controls.bankKind.setValue(localStorage.bankKind || '');

    // switch (localStorage.bankKind) {
    //   case 'KB':
    //     this.onBankClick(this.bankKB.nativeElement, this.bankKEB.nativeElement);
    //     break;
    //
    //   case 'KEB':
    //     this.onBankClick(this.bankKEB.nativeElement, this.bankKB.nativeElement);
    //     break;
    // }
  }

  onSignatureClear() {
    this.signaturePad.clear();
  }

  onPrev() {
    this.router.navigate(['/step-input-seller02'], { replaceUrl: false });
  }

  onNext() {
    console.log(this.myForm);

    if (this.myForm.valid ) {

      if (!this.agree1) {
        UIkit.modal(this.modalAgreeRef.nativeElement).show();
        return;
      }
      UIkit.modal(this.modalSignRef.nativeElement).show();
    }
  }


  onCloseModal(modal) {
    UIkit.modal(modal).hide();
  }

  onSignConfirm(modal) {

    UIkit.modal(modal).hide();

    localStorage.bankKind = this.myForm.value.bankKind;
    localStorage.accountNo = this.myForm.value.accountNo;
    localStorage.accountName = this.myForm.value.accountName;

    localStorage.signImageDataUrlBank = this.signaturePad.toDataURL();
    console.log(localStorage.signImageDataUrlBank);

    this.router.navigate(['/step-input-seller04'], { replaceUrl: false });
  }
  //
  // get bankKind() {
  //
  //   if (this.bankKB.nativeElement.selected ) {
  //     return 'KB';
  //   }
  //
  //   if (this.bankKEB.nativeElement.selected ) {
  //     return 'KEB';
  //   }
  //
  //   return null;
  // }

  onBankClick(a, b) {
    a.selected = true;
    b.selected = false;
    a.className = a.className.replace('uk-button-default', 'uk-button-primary');
    b.className = b.className.replace('uk-button-primary', 'uk-button-default');
  }
}
