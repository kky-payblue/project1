import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputSeller04Component } from './step-input-seller04.component';

describe('StepInputSeller04Component', () => {
  let component: StepInputSeller04Component;
  let fixture: ComponentFixture<StepInputSeller04Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputSeller04Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputSeller04Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
