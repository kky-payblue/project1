import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {FormControl, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-step-input-seller04',
  templateUrl: './step-input-seller04.component.html',
  styleUrls: ['./step-input-seller04.component.css']
})
export class StepInputSeller04Component implements OnInit {

  myForm = new FormGroup({
    membershipFee: new FormControl(''),
    serviceItemKind: new FormControl('')
  });

  individual = true;

  constructor(private router: Router) {}

  ngOnInit() {
    if (!localStorage.accountNo ) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    this.individual = localStorage.sellerType === 'individual';

    if (localStorage.membershipFee) {
      this.myForm.controls.membershipFee.setValue(localStorage.membershipFee);
    } else {
      this.myForm.controls.membershipFee.setValue('once2_50000');
    }

    let kindValue = null;
    if (!this.individual) {
      if (!localStorage.serviceItemKind || (localStorage.serviceItemKind !== 'PBBIZ 프리미엄' && localStorage.serviceItemKind !== 'PBBIZ 라이트')) {
        kindValue = 'PBBIZ 프리미엄';
      } else {
        kindValue = localStorage.serviceItemKind;
      }
    } else {
      if (!localStorage.serviceItemKind || (localStorage.serviceItemKind !== 'PB200 프리미엄' && localStorage.serviceItemKind !== 'PB200 라이트')) {
        kindValue = 'PB200 프리미엄';
      } else {
        kindValue = localStorage.serviceItemKind;
      }
    }

    this.myForm.controls.serviceItemKind.setValue(kindValue);
  }

  onPrev() {
    this.router.navigate(['/step-input-seller03'], { replaceUrl: false });
  }

  onNext() {
    console.log(this.myForm);

    if (this.myForm.valid ) {

      localStorage.membershipFee = this.myForm.value.membershipFee;
      localStorage.serviceItemKind = this.myForm.value.serviceItemKind;

      this.router.navigate(['/step-input-seller05'], { replaceUrl: false });
    }
  }

}
