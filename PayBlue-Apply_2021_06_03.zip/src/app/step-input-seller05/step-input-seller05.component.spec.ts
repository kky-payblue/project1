import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputSeller05Component } from './step-input-seller05.component';

describe('StepInputSeller05Component', () => {
  let component: StepInputSeller05Component;
  let fixture: ComponentFixture<StepInputSeller05Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputSeller05Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputSeller05Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
