import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {FormControl, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-step-input-seller05',
  templateUrl: './step-input-seller05.component.html',
  styleUrls: ['./step-input-seller05.component.css']
})
export class StepInputSeller05Component implements OnInit {

  myForm = new FormGroup({
    readerDeviceKind: new FormControl(''),
    printerKind: new FormControl('')
  });

  individual = true;

  icBlueCheck_145000_value;
  btSewoo_140000_value;

  constructor(private router: Router) {}

  ngOnInit() {
    if (!localStorage.accountNo ) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    this.individual = localStorage.sellerType === 'individual';

    if (!localStorage.readerDeviceKind) {
      localStorage.readerDeviceKind = 'none';
    }

    if (!localStorage.printerKind) {
      localStorage.printerKind = 'none';
    }

    if ( localStorage.frOnlineDealingDevice === 'Y' ) {
      this.icBlueCheck_145000_value = 'icBlueCheck_145000';
      this.btSewoo_140000_value = 'btSewoo_140000';

      if (localStorage.readerDeviceKind.indexOf('offline_') !== -1 ) {
        localStorage.readerDeviceKind = 'none';
      }

      if (localStorage.printerKind.indexOf('offline_') !== -1 ) {
        localStorage.printerKind = 'none';
      }
    } else {
      this.icBlueCheck_145000_value = 'offline_icBlueCheck_145000';
      this.btSewoo_140000_value = 'offline_btSewoo_140000';

      if (localStorage.readerDeviceKind.indexOf('offline_') === -1 ) {
        localStorage.readerDeviceKind = 'none';
      }

      if (localStorage.printerKind.indexOf('offline_') === -1 ) {
        localStorage.printerKind = 'none';
      }
    }


    this.myForm.controls.readerDeviceKind.setValue( localStorage.readerDeviceKind );
    this.myForm.controls.printerKind.setValue( localStorage.printerKind );
  }

  onPrev() {
    this.router.navigate(['/step-input-seller04'], { replaceUrl: false });
  }

  onNext() {

    if (this.myForm.valid ) {

      localStorage.readerDeviceKind = this.myForm.value.readerDeviceKind;
      localStorage.printerKind = this.myForm.value.printerKind;

      this.router.navigate(['/step-payment01'], { replaceUrl: false });
    }
  }


}
