import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepInputSeller06Component } from './step-input-seller06.component';

describe('StepInputSeller06Component', () => {
  let component: StepInputSeller06Component;
  let fixture: ComponentFixture<StepInputSeller06Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepInputSeller06Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepInputSeller06Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
