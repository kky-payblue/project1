import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {NumberPipe} from '../pipes/number.pipe';
import {AngularFireStorage} from '@angular/fire/storage';
import {finalize, flatMap} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {SharedService} from '../services/sharedService';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';

import * as FileSaver from 'file-saver';

declare var UIkit: any;

@Component({
  selector: 'app-step-input-seller06',
  templateUrl: './step-input-seller06.component.html',
  styleUrls: ['./step-input-seller06.component.css']
})
export class StepInputSeller06Component implements OnInit {

  msg;

  individual = true;

  uploadIdPercent: Observable<number>;
  uploadBankbookPercent: Observable<number>;
  uploadBusinessLicensePercent: Observable<number>;

  uploadedIdCardPicPath;
  uploadedBankbookPicPath;
  uploadedBusinessLicensePicPath;

  completed = false;

  frOnlineDealingDevice = true;
  frName = '';
  frCode = '';
  frAddress = '';
  frTel = '';

  constructor(private router: Router, private numberPipe: NumberPipe, private storage: AngularFireStorage, private http: HttpClient) {}

  ngOnInit() {

    if (!localStorage.dbPath ) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    this.msg = '* 신청인: ' + localStorage.name + '(' + this.numberPipe.transform(localStorage.tel, false) + ')';

    this.individual = localStorage.sellerType === 'individual';

    this.frOnlineDealingDevice = localStorage.frOnlineDealingDevice === 'Y';

    this.uploadedIdCardPicPath = localStorage.idCardPicPath;
    this.uploadedBankbookPicPath = localStorage.bankBookPicPath;
    this.uploadedBusinessLicensePicPath = localStorage.businessLicensePicPath;

    this.frCode = localStorage.frCode;
    this.frName = localStorage.frName;
    this.frTel = localStorage.frTel;
    this.frAddress = localStorage.frAddress;
  }

  onFrInfoDownload() {
    const data =
      '페이블루 신청 영업점 코드: ' + localStorage.frCode + '\r\n' +
      '상호: ' + localStorage.frName + '\r\n' +
      '전화번호: ' + localStorage.frTel + '\r\n' +
      '주소: ' + localStorage.frAddress + '\r\n';

    const fileName = '페이블루-영업점정보(' + localStorage.frCode + ').txt';

    // const hiddenElement = <any>document.createElement('a');
    // hiddenElement.href = 'data:text/plain;' + fileName + ';charset=utf-8,' + encodeURI(data);
    // hiddenElement.target = '_blank';
    // hiddenElement.download = fileName;
    // hiddenElement.click();

    const hdr = new Uint8Array(3);
    hdr[0] = 0xEF;
    hdr[1] = 0xBB;
    hdr[2] = 0xBF;

    FileSaver.saveAs(new Blob([hdr, data],  { type: 'text/plain;charset=utf-8' }), fileName);
  }

  uploadIdFile(event) {
    const file = event.target.files[0];
    const filePath = 'applicationForms/' + localStorage.dbPath + '/IdCardPic.' + SharedService.getFileExt(file.name);
    const fileRef = this.storage.ref(filePath);
    const task = this.storage.upload(filePath, file);

    // observe percentage changes
    this.uploadIdPercent = task.percentageChanges();

    task.snapshotChanges().pipe(
      flatMap( v => {
        return this.http.post(environment.functionUrl + '/u_apply_item',
          {
            dbPath: localStorage.dbPath,
            itemName: 'idCardPicPath',
            itemValue: filePath
          });
      }),
      finalize(() => {
        localStorage.idCardPicPath = filePath;
        this.uploadedIdCardPicPath = filePath;
      })
      )
      .subscribe();
  }

  uploadBankbookFile(event) {
    const file = event.target.files[0];
    const filePath = 'applicationForms/' + localStorage.dbPath + '/BankBookPic.' + SharedService.getFileExt(file.name);
    const fileRef = this.storage.ref(filePath);
    const task = this.storage.upload(filePath, file);

    // observe percentage changes
    this.uploadBankbookPercent = task.percentageChanges();

    task.snapshotChanges().pipe(
      flatMap( v => {
        return this.http.post(environment.functionUrl + '/u_apply_item',
          {
            dbPath: localStorage.dbPath,
            itemName: 'bankBookPicPath',
            itemValue: filePath
          });
      }),
      finalize(() => {
        localStorage.bankBookPicPath = filePath;
        this.uploadedBankbookPicPath = filePath;
      })
    )
      .subscribe();
  }

  uploadBusinessLicenseFile(event) {
    const file = event.target.files[0];
    const filePath = 'applicationForms/' + localStorage.dbPath + '/BusinessLicensePic.' + SharedService.getFileExt(file.name);
    const fileRef = this.storage.ref(filePath);
    const task = this.storage.upload(filePath, file);

    // observe percentage changes
    this.uploadBusinessLicensePercent = task.percentageChanges();

    task.snapshotChanges().pipe(
      flatMap( v => {
        return this.http.post(environment.functionUrl + '/u_apply_item',
          {
            dbPath: localStorage.dbPath,
            itemName: 'businessLicensePicPath',
            itemValue: filePath
          });
      }),
      finalize(() => {
        localStorage.businessLicensePicPath = filePath;
        this.uploadedBusinessLicensePicPath = filePath;
      })
    )
      .subscribe();
  }

  onPrev() {
    this.router.navigate(['/step-payment01'], { replaceUrl: false });
  }

  onComplete(modal) {
    UIkit.modal(modal).hide();
    // localStorage.clear();
    this.completed = true;
    localStorage.completed = 'true';

    history.pushState(null, null, location.href);
    window.onpopstate = function(event) {
      history.go(1);
    };
  }
}



