import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepPayment01Component } from './step-payment01.component';

describe('StepPayment01Component', () => {
  let component: StepPayment01Component;
  let fixture: ComponentFixture<StepPayment01Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepPayment01Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepPayment01Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
