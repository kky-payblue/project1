import {Component, OnInit} from '@angular/core';
import {CurrencyPipe} from '@angular/common';

import {Router} from '@angular/router';
import {environment} from '../../environments/environment';
import {HttpClient, HttpParams} from '@angular/common/http';
import {SharedService} from '../services/sharedService';
import {NumberPipe} from '../pipes/number.pipe';
import {FormControl, FormGroup} from '@angular/forms';
import * as FileSaver from 'file-saver';

declare var UIkit: any;

@Component({
  selector: 'app-step-payment01',
  templateUrl: './step-payment01.component.html',
  styleUrls: ['./step-payment01.component.css']
})
export class StepPayment01Component implements OnInit {

  /*
  localStorage.frCode;
  // '1111'

  localStorage.sellerType;
  // 'business', 'individual'

  localStorage.name = this.myForm.value.name;
  localStorage.tel = this.myForm.value.tel;

  localStorage.telKind = telKind;
  'SKT', 'KT', 'LGT', 'MVNO'

  localStorage.phoneKind = phoneKind;
  'iPhone', 'Android'


  localStorage.regNo = this.myForm.value.regNo;
  localStorage.email = this.myForm.value.email;
  localStorage.address = this.myForm.value.address;

  localStorage.shopName = this.myForm.value.shopName;
  localStorage.shopAddress = this.myForm.value.shopAddress;
  localStorage.shopItem = this.myForm.value.shopItem;

  은행
  bankKind
  'KB'
  'KEB'

  계좌번호
  accountNo

  예금주
  accountName

  가입비
  membershipFee
  'once_50000' // 호환성 유지
  '5month_50000' // 호환성 유지
  'card_5000' // new
  'event_0' // new

  요금제
  serviceItemKind
  'PB200'
  'PB400'

  리더기
  readerDeviceKind
  'none', 'icBlueCheck_145000'

  프린터
  printerKind
  'none', 'btSewoo_140000'

  */

  cardForm = new FormGroup({
    cardNo: new FormControl(''),
    cardDate: new FormControl('')
  });

  membershipFee = '';
  readerDevice = '';
  printer = '';
  finalAmount = '';

  membershipFeeAmountVal = 0;
  readerDeviceAmountVal = 0;
  printerAmountVal = 0;
  finalAmountVal = 0;

  paidMsg;
  inProgress = false;

  selectedPaymentKind = null;

  isPayButtonClicked = false;

  constructor(private router: Router,
              private currencyPipe: CurrencyPipe,
              private numberPipe: NumberPipe,
              private http: HttpClient,
              private ss: SharedService) { }

  ngOnInit() {
    try {
      if (!this.load()) {
        this.router.navigate(['/'], { replaceUrl: false });
        return;
      }
    } catch (error) {
      this.router.navigate(['/'], { replaceUrl: false });
      return;
    }

    if (localStorage.paymentApprovalDateTime &&
      localStorage.finalAmountVal === String(this.finalAmountVal)) {
      this.paidMsg =
        [
          '결제금액: ' + this.currencyPipe.transform(localStorage.finalAmountVal, 'KRW', 'code', '.0').replace('KRW', '') + '원',
          '결제시간: ' + SharedService.getyyyy_mm_dd_hh$mi$ss(SharedService.getGMTDateFromLocalyyyymmddhhmiss(localStorage.paymentApprovalDateTime))];
    }
  }

  load(): boolean {
    const s = localStorage;

    if (!s.readerDeviceKind ) {
      return false;
    }

    if (s.frCode.length === 0 ) {
      return false;
    }

    if (s.sellerType.length === 0 ) {
      return false;
    }

    if (s.name.length === 0 ) {
      return false;
    }

    if (s.tel.length === 0 ) {
      return false;
    }

    if (s.serviceItemKind.length === 0 ) {
      return false;
    }

    if (s.readerDeviceKind.length === 0 ) {
      return false;
    }

    if (s.printerKind.length === 0 ) {
      return false;
    }

    this.membershipFee = '가입비: ';
    if ( s.membershipFee === 'once2_50000' ) {
      this.membershipFee += '50,000원 납부 (VAT별도)';
      this.membershipFeeAmountVal = 50000;
    } else if ( s.membershipFee === 'event_0' ) {
      this.membershipFee += '이벤트 면제';
    } else {
      return false;
    }

    this.readerDevice = '결제 리더기: ';
    if ( s.readerDeviceKind === 'none' ) {
      this.readerDevice += '없음';
    } else if ( s.readerDeviceKind === 'icBlueCheck_145000' ) {
      this.readerDevice += '145,000원 (VAT별도)';
      this.readerDeviceAmountVal = 145000;
    } else if ( s.readerDeviceKind === 'offline_icBlueCheck_145000' ) {
      this.readerDevice += '신청(별도 안내 예정)';
      this.readerDeviceAmountVal = 0;
    } else {
      return false;
    }

    this.printer = '영수증 프린터: ';
    if ( s.printerKind === 'none' ) {
      this.printer += '없음';
    } else if ( s.printerKind === 'btSewoo_140000' ) {
      this.printer += '140,000원 (VAT별도)';
      this.printerAmountVal = 140000;
    } else if ( s.printerKind === 'offline_btSewoo_140000' ) {
      this.printer += '신청(별도 안내 예정)';
      this.printerAmountVal = 0;
    } else {
      return false;
    }

    this.finalAmountVal = this.membershipFeeAmountVal + this.readerDeviceAmountVal + this.printerAmountVal;
    this.finalAmount = '최종 결제금액: '
      + this.currencyPipe.transform(this.finalAmountVal, 'KRW', 'code').replace('KRW', '')
      + '원 (VAT별도)';

    // VAT 처리
    this.membershipFeeAmountVal *= 1.1;
    this.readerDeviceAmountVal *= 1.1;
    this.printerAmountVal *= 1.1;
    this.finalAmountVal = this.membershipFeeAmountVal + this.readerDeviceAmountVal + this.printerAmountVal;
    return true;
  }

  onPrev() {
    this.router.navigate(['/step-input-seller05'], { replaceUrl: false });
  }

  onShowPay(modal) {
    this.isPayButtonClicked = true;
    if (this.finalAmountVal > 0 && !this.selectedPaymentKind) {
      return;
    }
    this.cardForm.controls.cardNo.setValue('');
    this.cardForm.controls.cardDate.setValue('');
    UIkit.modal(modal).show();
  }

  onKeyUpCardNo(c, el, event) {
    if (event && event.which === 8) {
      return;
    }

    const pattern = /([0-9]{4})([0-9]{4})?([0-9]{4})?([0-9]{4})?/;
    let value = el.value.replace(/-/g, '').replace( pattern, '$1-$2-$3-$4' );
    // value = value.replace(/-{2, 3, 4}/g, '-');
    value = value.replace(/---/g, '-');
    value = value.replace(/--/g, '-');
    c.setValue(value);
  }

  onKeyUpCardDate(c, el, event) {
    if (event && event.which === 8) {
      return;
    }
    const pattern = /([0-9]{2})([0-9]{2})?/;
    c.setValue(el.value.replace(/\//g, '').replace( pattern, '$1/$2' ));
  }

  onAccountInfoDownload() {
    const amountDesc = '총 금액: '
    + this.currencyPipe.transform(this.finalAmountVal, 'KRW', 'code').replace('KRW', '')
    + '원 (VAT포함)';
    const data =
      '은행명: 국민은행\r\n' +
      '예금주: (주)블루티에프\r\n' +
      '계좌번호: 547801-04-153804\r\n' +
      amountDesc + '\r\n';

    const fileName = '페이블루신청-계좌번호.txt';

    // const hiddenElement = <any>document.createElement('a');
    // hiddenElement.href = 'data:text/plain;' + fileName + ';charset=utf-8,' + encodeURI(data);
    // hiddenElement.target = '_blank';
    // hiddenElement.download = fileName;
    // hiddenElement.click();

    const hdr = new Uint8Array(3);
    hdr[0] = 0xEF;
    hdr[1] = 0xBB;
    hdr[2] = 0xBF;

    FileSaver.saveAs(new Blob([hdr, data],  { type: 'text/plain;charset=utf-8' }), fileName);
  }

  onPay(modal) {
    if (this.selectedPaymentKind === 'byCardPayment' && this.cardForm.invalid) {
      return;
    }

    UIkit.modal(modal).hide();


    localStorage.membershipFeeAmountVal = String(this.membershipFeeAmountVal);
    localStorage.readerDeviceAmountVal = String(this.readerDeviceAmountVal);
    localStorage.printerAmountVal = String(this.printerAmountVal);
    localStorage.finalAmountVal = String(this.finalAmountVal);

    if ( this.finalAmountVal === 0 ) {
      // 결제 필요 없음

      if (localStorage.paymentType !== 'NONE') {
        localStorage.paymentType = 'NONE';
        localStorage.paymentApprovalDateTime = SharedService.getyyyymmddhhmiss();
      }

      this.performSaveToServerAndNext();

    } else if ( this.selectedPaymentKind === 'byAccountTransfer') {
      // 계좌 이체

      if (localStorage.paymentType !== 'ACCOUNT_TRANSFER') {
        localStorage.paymentType = 'ACCOUNT_TRANSFER';
        localStorage.paymentApprovalDateTime = SharedService.getyyyymmddhhmiss();
      }

      this.performSaveToServerAndNext();

    } else {

      // 결제 성공
      if (this.cardForm.invalid) {
        return;
      }

      if (!environment.production) {

        localStorage.paymentType = 'CARD';
        localStorage.paymentApprovalNo = '99999999';
        localStorage.paymentCardNo = '111122******4444';

        this.performSaveToServerAndNext();
        return;
      }

      // 결제 로직
      const cardNo = this.cardForm.controls.cardNo.value.replace(/[\-_]|/g, '');
      const payData = {
        cardVal : cardNo + '=' + this.cardForm.controls.cardDate.value.substr(3, 2) + this.cardForm.controls.cardDate.value.substr(0, 2),
        swipeVal : false,
        sumVal : Number(this.finalAmountVal).toFixed(0),
        monthVal : 0,
        custPhoneNo : '16445439',
        sellerId : this.ss.removeDash(localStorage.tel)
      };

      const payDataStr = JSON.stringify(payData);

      console.log(payData);

      const httpParams = new HttpParams()
        .append('command', 'BPAKsnetPaymentCommandExt')
        .append('data', payDataStr);

      this.http.post(environment.paymentUrl, httpParams).toPromise()
        .catch( error => {
          console.log(error);
          throw new Error('결제 서버 오류(1)');
        })
        .then((res: any) => {
          console.log(res);

          if ( res.status !== 'OK' || res.data == null ) {
            throw new Error('결제 서버 오류(2)');
          }

          if ( res.data.Status !== 'O' ) {
            let msg = '결제 거절: ';
            if ( res.data.Message1 ) {
              msg += res.data.Message1;
            }
            if ( res.data.Message2 ) {
              msg += '\n' + res.data.Message2;
            }
            throw new Error(msg);
          }

          // 결제 성공
          localStorage.paymentType = 'CARD';
          localStorage.paymentApprovalDateTime = res.data.TradeDate + res.data.TradeTime;
          localStorage.paymentApprovalNo = res.data.VanTransactionNo;
          localStorage.paymentCardNo = res.data.CardNo;

          this.performSaveToServerAndNext();

        })
        .catch( error => {
          alert(error.toString());
        });
    }

  }

  onPayClose(modal) {
    UIkit.modal(modal).hide();
  }

  performSaveToServerAndNext(modal = null) {
    if (modal) {
      UIkit.modal(modal).hide();
    }

    // 서버 저장
    const data = {
      // ts: {'.sv': 'timestamp'}, function에서 설정하기로 해서 주석처리

      versionCode: localStorage.versionCode,

      frName: localStorage.frName  || '',
      frAddress: localStorage.frAddress  || '',
      frTel: localStorage.frTel || '',
      frCode: 'FR' + localStorage.frCode,
      frOnlineDealingDevice: localStorage.frOnlineDealingDevice || '',

      sellerType: localStorage.sellerType, // 'business', 'individual'

      name: localStorage.name,
      tel: this.ss.removeDash(localStorage.tel),

      telKind: localStorage.telKind, // 'SKT', 'KT', 'LGT', 'MVNO'
      phoneKind: localStorage.phoneKind, // 'iPhone', 'Android'

      regNo: this.ss.removeDash(localStorage.regNo),
      sex: localStorage.sex,
      email: localStorage.email,

      postCode: localStorage.postCode,
      address: localStorage.address,
      addressDetail: localStorage.addressDetail,

      shopName: localStorage.shopName,
      shopItem: localStorage.shopItem,

      shopPostCode: localStorage.shopPostCode,
      shopAddress: localStorage.shopAddress,
      shopAddressDetail: localStorage.shopAddressDetail,

      businessNo: this.ss.removeDash(localStorage.businessNo),

      bankKind: localStorage.bankKind, // 'KB', 'KEB'
      accountNo: localStorage.accountNo,
      accountName: localStorage.accountName,

      signImageDataUrl: localStorage.signImageDataUrl,
      signImageDataUrlBank: localStorage.signImageDataUrlBank,
      signImageDataUrlKspay: localStorage.signImageDataUrlKspay,

      membershipFee: localStorage.membershipFee, // 'once_50000', '5month_50000', 'event_0', 'once2_50000'
      serviceItemKind: localStorage.serviceItemKind, // 'PB200', 'PB400'

      readerDeviceKind: localStorage.readerDeviceKind, // 'none', 'icBlueCheck_145000'
      printerKind: localStorage.printerKind, // 'none', 'btSewoo_140000'

      membershipFeeAmountVal: Math.floor(Number(localStorage.membershipFeeAmountVal)),
      readerDeviceAmountVal: Math.floor(Number(localStorage.readerDeviceAmountVal)),
      printerAmountVal: Math.floor(Number(localStorage.printerAmountVal)),

      finalAmountVal: Math.floor(Number(localStorage.finalAmountVal)),

      paymentType: localStorage.paymentType,
      paymentApprovalDateTime: localStorage.paymentApprovalDateTime || '',
      paymentApprovalNo: localStorage.paymentApprovalNo || '',
      paymentCardNo: localStorage.paymentCardNo || '',

      dbPath: localStorage.dbPath || '',

      idCardPicPath: localStorage.idCardPicPath || '',
      bankBookPicPath: localStorage.bankBookPicPath || '',
      businessLicensePicPath: localStorage.businessLicensePicPath || ''

    };

    if (!data.shopAddress) {
      data.shopAddress = data.address;
    }

    const jsonData = JSON.stringify(data);

    console.log(jsonData);

    this.inProgress = true;

    this.http.post(environment.functionUrl + '/r_apply', data).toPromise()
      .catch( error => {
        throw new Error('서버 오류(1)');
      })
      .then((res: any) => {
        console.log(res);

        this.inProgress = false;

        if (res.result === 'OK' ) {
          localStorage.dbPath = res.dbPath;

          // 다음으로
          this.onNext();
          return;
        }

        throw new Error('서버 저장 오류');
      })
      .catch( error => {
        console.log(error.toString());
        this.inProgress = false;
        alert(error.toString());
      });

  }

  onNext() {
    this.router.navigate(['/step-input-seller06'], { replaceUrl: false });
  }
}
