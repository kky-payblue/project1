import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router} from '@angular/router';
import {HttpClient} from '@angular/common/http';

import {
  zip
} from 'rxjs';
import {FormControl, FormGroup} from '@angular/forms';
import {SharedService} from '../services/sharedService';

declare var UIkit: any;

@Component({
  selector: 'app-step-start',
  templateUrl: './step-start.component.html',
  styleUrls: ['./step-start.component.css']
})
export class StepStartComponent implements OnInit {

  versionCode = '5';
  versionName = '1.5';

  myGroup = new FormGroup({
    tel: new FormControl('')
  });

  @ViewChild('modalAgree') modalAgreeRef: ElementRef;
  @ViewChild('modalConfirm') modalConfirmRef: ElementRef;

  constructor(private router: Router, private http: HttpClient, public ss: SharedService) { }

  ngOnInit() {

    if (!localStorage.versionCode || Number(localStorage.versionCode) < Number(this.versionCode) ) {
      localStorage.clear();
    }

    localStorage.versionCode = this.versionCode;
    sessionStorage.completed = 'false';
  }

  onNext() {
    localStorage.Start = 'true';

    if (localStorage.tel) {
      console.log(this.modalConfirmRef.nativeElement);
      UIkit.modal(this.modalConfirmRef.nativeElement).show();
    } else {
      console.log(this.router.navigate);
      this.router.navigate(['/step-input-franchise-code'], { replaceUrl: false })
        .catch(error => {
          console.log(error);
        });
    }
  }

  onModifyContinue(modal, modal2) {
    UIkit.modal(modal).hide();
    UIkit.modal(modal2).show();
  }

  onModifyContinue2(modal) {
    if (localStorage.tel && this.myGroup.controls.tel.value !== localStorage.tel) {
      alert('신청중인 정보와 일치하지 않습니다.');
      return;
    }

    UIkit.modal(modal).hide();

    if (localStorage.dbPath) {
      this.router.navigate(['/step-input-seller06'], {replaceUrl: false});
    } else if(localStorage.paymentApprovalDateTime) {
      this.router.navigate(['/step-payment01'], {replaceUrl: false});
    } else {
      this.router.navigate(['/step-input-franchise-code'], {replaceUrl: false});
    }
  }

  onNewContinue(modal) {
    if (confirm('진행중이던 내용은 초기화 됩니다. 계속 하시겠습니까?')) {
      localStorage.clear();
      localStorage.Start = 'true';
      this.onModifyContinue2(modal);
    }
  }

  onCloseModal(modal) {
    UIkit.modal(modal).hide();
  }
}
