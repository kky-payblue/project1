export const environment = {
  production: true,

  // paymentUrl: 'https://pay.bluetf.com/BizWON/Command',
  // paymentUrl: 'http://182.162.136.161:8080/BizWON/Command',
  paymentUrl: 'https://20190828t000729-dot-payblue-d4b56.appspot.com/pb/ksnetOnlineCardPayBlueTF',

  functionUrl: 'https://us-central1-payblue-d4b56.cloudfunctions.net',

  firebaseConfig : {
    apiKey: 'AIzaSyA3R2F6RB_8oXuYXcdFvHEMismpA2gyVI4',
    authDomain: 'payblue-d4b56.firebaseapp.com',
    databaseURL: 'https://payblue-d4b56.firebaseio.com',
    projectId: 'payblue-d4b56',
    storageBucket: 'payblue-d4b56.appspot.com',
    messagingSenderId: '94892994810'
  }
};
