// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,

  // paymentUrl: 'https://pay.bluetf.com/BizWON/Command',
  // paymentUrl: 'http://182.162.136.161:8080/BizWON/Command',
  paymentUrl: 'https://payblue-d4b56.appspot.com/pb/ksnetOnlineCardPayBlueTF',



  functionUrl: 'https://us-central1-payblue-test.cloudfunctions.net',
  // functionUrl: 'http://localhost:5000/payblue-test/us-central1',

  firebaseConfig : {
    apiKey: 'AIzaSyDzeN5l-tV1we2CaTYigIPZLC5YXg2BSro',
    authDomain: 'payblue-test.firebaseapp.com',
    databaseURL: 'https://payblue-test.firebaseio.com',
    projectId: 'payblue-test',
    storageBucket: 'payblue-test.appspot.com',
    messagingSenderId: '380883211409'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
